package core;

import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.net.InetSocketAddress;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import com.sun.net.httpserver.HttpExchange;
import com.sun.net.httpserver.HttpHandler;
import com.sun.net.httpserver.HttpServer;


public class MyServer
{

    public static void print(Object o)
    {
        System.out.println(o);
    }

    public static void main(String[] args)  throws Exception
    {

        HttpServer server = HttpServer.create(new InetSocketAddress(8000), 0);
        server.createContext("/", new HandleDefault());
        server.createContext("/test", new HandleTest());
        server.createContext("/pyx", new HandlePyx());
        server.setExecutor(null); // creates a default executor
        server.start();

    }

    private static HashMap<String, String> getPOSTParamsFromRequest(HttpExchange he)
    {
        if (!he.getRequestMethod().equalsIgnoreCase("POST")) return null;
        HashMap<String, String> map = new HashMap<String, String>();
        String reqBody = InputStreamToString(he.getRequestBody());
        if (reqBody.contains("Content-Disposition: form-data")) return null;
        if (reqBody.contains("&"))
        {
            String[] pairs = reqBody.split("&");
            for (String p : pairs)
            {
                map.put( p.split("=")[0], p.split("=")[1] );
            }
        }
        else
        {
            map.put( reqBody.split("=")[0], reqBody.split("=")[1] );
        }

        return map;
    }

    private static HashMap<String, String> getGETParamsFromRequest(HttpExchange he)
    {
        if (!he.getRequestMethod().equalsIgnoreCase("GET")) return null;
        HashMap<String, String> map = new HashMap<String, String>();
        if (he.getRequestURI().toString().contains("?"))
        {
            String[] urlParts = he.getRequestURI().toString().split("\\?");
            if (urlParts[1].contains("&"))
            {
                for (String p : urlParts[1].split("&"))
                {
                    map.put( p.split("=")[0], p.split("=")[1] );
                }
            }
            else
            {
                map.put( urlParts[1].split("=")[0], urlParts[1].split("=")[1] );
            }
        }
        else return null;

        return map;
    }

    private static String InputStreamToString(InputStream is)
    {
        java.util.Scanner s = new java.util.Scanner(is, "UTF-8").useDelimiter("\\A");
        return s.hasNext() ? s.next() : "";
    }

    static class HandleTest implements HttpHandler
    {
        @Override
        public void handle(HttpExchange t) throws IOException
        {
            print("\nTEST Route - Incoming request");
            print("REQUEST METHOD: "  + t.getRequestMethod());
            String response = "This is the test route";
            t.sendResponseHeaders(200, response.length());
            OutputStream os = t.getResponseBody();
            os.write(response.getBytes());
            os.close();

            t.close();
        }

    }

    static class HandlePyx implements HttpHandler
    {
        @Override
        public void handle(HttpExchange t) throws IOException
        {
            print("\nPYX Route - Incoming request");
            print("REQUEST METHOD: "  + t.getRequestMethod());
            String response = "This is the pyx route";
            t.sendResponseHeaders(200, response.length());
            OutputStream os = t.getResponseBody();
            os.write(response.getBytes());
            os.close();

            t.close();
        }


    }

    static class HandleDefault implements HttpHandler
    {
        @Override
        public void handle(HttpExchange t) throws IOException
        {
            print("\nDefault Route - Incoming request");
            print("REQUEST METHOD: "  + t.getRequestMethod());
            print("REQUEST URI: "  + t.getRequestURI());
            print("REQUEST HEADERS: ");

            for (Map.Entry<String, List<String>> entry : t.getRequestHeaders().entrySet()) {
                System.out.println("\t" + entry.getKey() + ":\t" + entry.getValue());
            }

            if (t.getRequestMethod().equalsIgnoreCase("POST"))
            {
                print("POST PARAMS: ");
                HashMap<String, String> params = getPOSTParamsFromRequest(t);
                if (params != null)
                {
                    for (Map.Entry<String, String> entry : params.entrySet()) {
                        System.out.println("\t" + entry.getKey() + ": " + entry.getValue());
                    }
                }
            }
            else if (t.getRequestMethod().equalsIgnoreCase("GET"))
            {
                print("GET PARAMS: ");
                HashMap<String, String> params = getGETParamsFromRequest(t);
                if (params != null)
                {
                    for (Map.Entry<String, String> entry : params.entrySet()) {
                        System.out.println("\t" + entry.getKey() + ": " + entry.getValue());
                    }
                }
            }





            String response = "<h1>Default Route. Hello</h1>";
            t.sendResponseHeaders(200, response.length());
            OutputStream os = t.getResponseBody();
            os.write(response.getBytes());
            os.close();

            t.close();
        }


    }





}

