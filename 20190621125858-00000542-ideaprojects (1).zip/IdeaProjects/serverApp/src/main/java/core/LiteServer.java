package core;

import fi.iki.elonen.NanoHTTPD;

import java.io.IOException;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

public class LiteServer extends NanoHTTPD
{
    public static final int PORT = 8080;

    public LiteServer() throws IOException
    {
        super(PORT);
        start(NanoHTTPD.SOCKET_READ_TIMEOUT, false);
        System.out.println("\nRunning! Point your browsers to http://localhost:"+PORT+"/ \n");
    }

    public static void main(String[] args)
    {
        try
        {
            new LiteServer();
        }
        catch (IOException ioe)
        {
            System.err.println("Couldn't start server:\n" + ioe);
        }
    }

    public static void print(Object o)
    {
        System.out.println(o);
    }

    private static HashMap<String, String> queryParamStringToMap(String str)
    {
        HashMap<String, String> map = new HashMap<String, String>();
        if (str.contains("&"))
        {
            for (String p : str.split("&"))
            {
                map.put( p.split("=")[0], p.split("=")[1] );
            }
        }
        else
        {
            map.put( str.split("=")[0], str.split("=")[1] );
        }

        return map;
    }

    @Override
    public Response serve(IHTTPSession session)
    {
        String msg = "<html><body><h1>Hello server</h1>\n";

        print("\nIncoming Request!");
        print("REQUEST HEADERS: " + session.getHeaders());
        print("REQUEST METHOD: "  + session.getMethod() );
        print("REQUEST URI: "     + session.getUri() );

        if (Method.GET.equals(session.getMethod()))
        {
            Map<String, List<String>> params = session.getParameters(); // GET only
            print("REQUEST PARAMS: ");
            for (Map.Entry<String, List<String>> entry : params.entrySet()) {
                System.out.println("\t" + entry.getKey() + ":\t" + entry.getValue());
            }
        }
        else if ( Method.POST.equals(session.getMethod()) )
        {
            Map<String, String> files = new HashMap<String, String>();
            try {
                session.parseBody(files);
            }
            catch (Exception e) { e.printStackTrace(); }
            HashMap<String, String> paramMap = queryParamStringToMap(session.getQueryParameterString());
            if (paramMap != null)
            {
                print("REQUEST QUERY PARAMS: ");
                for (Map.Entry<String, String> entry : paramMap.entrySet()) {
                    System.out.println("\t" + entry.getKey() + ": " + entry.getValue());
                }
            }
        }

//        print("REQUEST HEADERS: ");
//
//        for (Map.Entry<String, List<String>> entry : t.getRequestHeaders().entrySet()) {
//            System.out.println("\t" + entry.getKey() + ":\t" + entry.getValue());
//        }

//        if (t.getRequestMethod().equalsIgnoreCase("POST"))
//        {
//            print("POST PARAMS: ");
//            HashMap<String, String> params = getPOSTParamsFromRequest(t);
//            if (params != null)
//            {
//                for (Map.Entry<String, String> entry : params.entrySet()) {
//                    System.out.println("\t" + entry.getKey() + ": " + entry.getValue());
//                }
//            }
//        }
//        else if (t.getRequestMethod().equalsIgnoreCase("GET"))
//        {
//            print("GET PARAMS: ");
//            HashMap<String, String> params = getGETParamsFromRequest(t);
//            if (params != null)
//            {
//                for (Map.Entry<String, String> entry : params.entrySet()) {
//                    System.out.println("\t" + entry.getKey() + ": " + entry.getValue());
//                }
//            }
//        }


//        if (parms.get("username") == null)
//        {
//            msg += "<form action='?' method='get'>\n  <p>Your name: <input type='text' name='username'></p>\n" + "</form>\n";
//        }
//        else
//        {
//            msg += "<p>Hello, " + parms.get("username") + "!</p>";
//        }
//        return newFixedLengthResponse(msg + "</body></html>\n");


        return newFixedLengthResponse("test out");
    }

}
